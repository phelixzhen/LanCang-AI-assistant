#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<vector>
#include<sstream>
using namespace std;
char ch[510][8000],cnt=1;
bool flag=0;
void save()
{
	if (cnt % 2) cnt -= 1;
	if (flag==1) cout << ',' << endl;
	else flag=1;
	cout << "  {" << endl;
	
	cout << "    \"instruction\": \"" << ch[cnt - 1] << "\"," << endl;
	cout << "    \"input\": \"\"," << endl;
	cout << "    \"output\": \"" << ch[cnt] << "\"";
	if (cnt>2)
	{
		cout<<','<<endl; 
		cout << "    \"history\": [" << endl;
	
		for (int i = 1; i <= cnt-2; i+=2)
		{
			cout << "      [\"" << ch[i] <<"\",\"" <<ch[i+1]<< "\"]";
			if (i!=1) cout<<',';
			cout<<endl;
		}
		cout << "    ]" << endl;
	} 
	else cout<<endl;
	cout << "  }";
	return;
}

int main()
{
	freopen("input.txt","r",stdin);
	freopen("output.txt", "w", stdout);
	cout << '[' << endl;
	bool stop=0;
	while (bool b = 1)
	{
		for (cnt = 1; cnt <= 500; cnt++)
		{
			string s;
			getline(cin,s);
			int d = 0;
			for (int i = 0; i <= s.length(); i++) {
				if (s[i] == '"') {
					ch[cnt][i + d] = '\\';
					d += 1;
				}
				ch[cnt][i+d] = s[i];
			}
			if (ch[cnt][0] == '/' && ch[cnt][1] == 'e' && ch[cnt][2] == 'n' && ch[cnt][3] == 'd') {
				cnt -= 1;
				break;
			}
			if (ch[cnt][0] == '/' && ch[cnt][1] == 's' && ch[cnt][2] == 't' && ch[cnt][3] == 'o' && ch[cnt][4] == 'p') {
				cnt -= 1;
				stop=1;
				break;
			}

		}
		if(cnt%2==1) cnt-=1;
		int car=cnt;
		/*for (int i = 2; i <= car; i += 2) {
			cnt=i;
			save();
		}*/
		save();
		if (stop) break;
	}
	
	cout <<endl << ']' << endl;
	return 0;
}
